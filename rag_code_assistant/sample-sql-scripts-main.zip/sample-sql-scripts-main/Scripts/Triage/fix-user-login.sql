Use config
GO

EXEC sp_change_users_login 'Auto_Fix', 'username', NULL, 'password'